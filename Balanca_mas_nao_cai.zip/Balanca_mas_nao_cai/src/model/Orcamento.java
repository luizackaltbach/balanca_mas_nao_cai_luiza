/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author luiza.kaltbach
 */
import java.time.LocalDate;

public class Orcamento {
    private int idOrcamento;
    private LocalDate dtAprovacao;
    private Engenheiro engenheiroResponsavel; 

    /**
     * @return the idOrcamento
     */
    public int getIdOrcamento() {
        return idOrcamento;
    }

    /**
     * @param idOrcamento the idOrcamento to set
     */
    public void setIdOrcamento(int idOrcamento) {
        this.idOrcamento = idOrcamento;
    }

    /**
     * @return the dtAprovacao
     */
    public LocalDate getDtAprovacao() {
        return dtAprovacao;
    }

    /**
     * @param dtAprovacao the dtAprovacao to set
     */
    public void setDtAprovacao(LocalDate dtAprovacao) {
        this.dtAprovacao = dtAprovacao;
    }

    /**
     * @return the engenheiroResponsavel
     */
    public Engenheiro getEngenheiroResponsavel() {
        return engenheiroResponsavel;
    }

    /**
     * @param engenheiroResponsavel the engenheiroResponsavel to set
     */
    public void setEngenheiroResponsavel(Engenheiro engenheiroResponsavel) {
        this.engenheiroResponsavel = engenheiroResponsavel;
    }
}