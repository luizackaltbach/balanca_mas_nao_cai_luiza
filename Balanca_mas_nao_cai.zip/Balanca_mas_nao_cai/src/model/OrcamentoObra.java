/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author luiza.kaltbach
 */
import java.math.BigDecimal;
import java.time.LocalDate;

public class OrcamentoObra {
    private Orcamento orcamento;
    private Obra obra;
    private LocalDate dtInicio;
    private LocalDate dtFim;
    private BigDecimal vlPrevisto;
    private BigDecimal vlRealizado;

    /**
     * @return the orcamento
     */
    public Orcamento getOrcamento() {
        return orcamento;
    }

    /**
     * @param orcamento the orcamento to set
     */
    public void setOrcamento(Orcamento orcamento) {
        this.orcamento = orcamento;
    }

    /**
     * @return the obra
     */
    public Obra getObra() {
        return obra;
    }

    /**
     * @param obra the obra to set
     */
    public void setObra(Obra obra) {
        this.obra = obra;
    }

    /**
     * @return the dtInicio
     */
    public LocalDate getDtInicio() {
        return dtInicio;
    }

    /**
     * @param dtInicio the dtInicio to set
     */
    public void setDtInicio(LocalDate dtInicio) {
        this.dtInicio = dtInicio;
    }

    /**
     * @return the dtFim
     */
    public LocalDate getDtFim() {
        return dtFim;
    }

    /**
     * @param dtFim the dtFim to set
     */
    public void setDtFim(LocalDate dtFim) {
        this.dtFim = dtFim;
    }

    /**
     * @return the vlPrevisto
     */
    public BigDecimal getVlPrevisto() {
        return vlPrevisto;
    }

    /**
     * @param vlPrevisto the vlPrevisto to set
     */
    public void setVlPrevisto(BigDecimal vlPrevisto) {
        this.vlPrevisto = vlPrevisto;
    }

    /**
     * @return the vlRealizado
     */
    public BigDecimal getVlRealizado() {
        return vlRealizado;
    }

    /**
     * @param vlRealizado the vlRealizado to set
     */
    public void setVlRealizado(BigDecimal vlRealizado) {
        this.vlRealizado = vlRealizado;
    }
}