/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author luiza.kaltbach
 */
import java.time.LocalDate;

public class Obra {
    private int idObra;
    private String descricao;
    private LocalDate dtInicio;
    private LocalDate dtFim;
    private Engenheiro engenheiro;
    private String nrCrea;
    private LocalDate dtDdmissaoEngenheiro;

    /**
     * @return the idObra
     */
    public int getIdObra() {
        return idObra;
    }

    /**
     * @param idObra the idObra to set
     */
    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * @return the dtInicio
     */
    public LocalDate getDtInicio() {
        return dtInicio;
    }

    /**
     * @param dtInicio the dtInicio to set
     */
    public void setDtInicio(LocalDate dtInicio) {
        this.dtInicio = dtInicio;
    }

    /**
     * @return the dtFim
     */
    public LocalDate getDtFim() {
        return dtFim;
    }

    /**
     * @param dtFim the dtFim to set
     */
    public void setDtFim(LocalDate dtFim) {
        this.dtFim = dtFim;
    }

    /**
     * @return the engenheiro
     */
    public Engenheiro getEngenheiro() {
        return engenheiro;
    }

    /**
     * @param engenheiro the engenheiro to set
     */
    public void setEngenheiro(Engenheiro engenheiro) {
        this.engenheiro = engenheiro;
    }

    /**
     * @return the nrCrea
     */
    public String getNrCrea() {
        return nrCrea;
    }

    /**
     * @param nrCrea the nrCrea to set
     */
    public void setNrCrea(String nrCrea) {
        this.nrCrea = nrCrea;
    }

    /**
     * @return the dtDdmissaoEngenheiro
     */
    public LocalDate getDtDdmissaoEngenheiro() {
        return dtDdmissaoEngenheiro;
    }

    /**
     * @param dtDdmissaoEngenheiro the dtDdmissaoEngenheiro to set
     */
    public void setDtDdmissaoEngenheiro(LocalDate dtDdmissaoEngenheiro) {
        this.dtDdmissaoEngenheiro = dtDdmissaoEngenheiro;
    }
}
