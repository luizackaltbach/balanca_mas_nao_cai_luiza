/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author luiza.kaltbach
 */
import java.time.LocalDate;

public class ObraEngenheiro {
    private Obra obra;
    private Engenheiro engenheiro;
    private LocalDate dtAdmissaoEngenheiro;
    private LocalDate dtInicioTrabalho;
    private LocalDate dtFimTrabalho;
    private Funcao funcao;

    /**
     * @return the obra
     */
    public Obra getObra() {
        return obra;
    }

    /**
     * @param obra the obra to set
     */
    public void setObra(Obra obra) {
        this.obra = obra;
    }

    /**
     * @return the engenheiro
     */
    public Engenheiro getEngenheiro() {
        return engenheiro;
    }

    /**
     * @param engenheiro the engenheiro to set
     */
    public void setEngenheiro(Engenheiro engenheiro) {
        this.engenheiro = engenheiro;
    }

    /**
     * @return the dtAdmissaoEngenheiro
     */
    public LocalDate getDtAdmissaoEngenheiro() {
        return dtAdmissaoEngenheiro;
    }

    /**
     * @param dtAdmissaoEngenheiro the dtAdmissaoEngenheiro to set
     */
    public void setDtAdmissaoEngenheiro(LocalDate dtAdmissaoEngenheiro) {
        this.dtAdmissaoEngenheiro = dtAdmissaoEngenheiro;
    }

    /**
     * @return the dtInicioTrabalho
     */
    public LocalDate getDtInicioTrabalho() {
        return dtInicioTrabalho;
    }

    /**
     * @param dtInicioTrabalho the dtInicioTrabalho to set
     */
    public void setDtInicioTrabalho(LocalDate dtInicioTrabalho) {
        this.dtInicioTrabalho = dtInicioTrabalho;
    }

    /**
     * @return the dtFimTrabalho
     */
    public LocalDate getDtFimTrabalho() {
        return dtFimTrabalho;
    }

    /**
     * @param dtFimTrabalho the dtFimTrabalho to set
     */
    public void setDtFimTrabalho(LocalDate dtFimTrabalho) {
        this.dtFimTrabalho = dtFimTrabalho;
    }

    /**
     * @return the funcao
     */
    public Funcao getFuncao() {
        return funcao;
    }

    /**
     * @param funcao the funcao to set
     */
    public void setFuncao(Funcao funcao) {
        this.funcao = funcao;
    }
}
