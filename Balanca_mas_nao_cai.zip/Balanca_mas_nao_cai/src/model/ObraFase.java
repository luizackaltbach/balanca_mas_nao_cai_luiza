/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author luiza.kaltbach
 */
import java.time.LocalDate;

public class ObraFase {
    private Obra obra;
    private Fase fase;
    private LocalDate dtInicioFase;
    private LocalDate dtTerminoFase;

    /**
     * @return the obra
     */
    public Obra getObra() {
        return obra;
    }

    /**
     * @param obra the obra to set
     */
    public void setObra(Obra obra) {
        this.obra = obra;
    }

    /**
     * @return the fase
     */
    public Fase getFase() {
        return fase;
    }

    /**
     * @param fase the fase to set
     */
    public void setFase(Fase fase) {
        this.fase = fase;
    }

    /**
     * @return the dtInicioFase
     */
    public LocalDate getDtInicioFase() {
        return dtInicioFase;
    }

    /**
     * @param dtInicioFase the dtInicioFase to set
     */
    public void setDtInicioFase(LocalDate dtInicioFase) {
        this.dtInicioFase = dtInicioFase;
    }

    /**
     * @return the dtTerminoFase
     */
    public LocalDate getDtTerminoFase() {
        return dtTerminoFase;
    }

    /**
     * @param dtTerminoFase the dtTerminoFase to set
     */
    public void setDtTerminoFase(LocalDate dtTerminoFase) {
        this.dtTerminoFase = dtTerminoFase;
    }
}
